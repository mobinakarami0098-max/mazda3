package com.mazda.launcher;

import android.service.notification.NotificationListenerService;

/** Empty on purpose: granting notification access lets the launcher read active media sessions. */
public class MediaListener extends NotificationListenerService {
}
