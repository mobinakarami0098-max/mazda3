package com.mazda.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView wv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient());
        wv.addJavascriptInterface(new Bridge(this), "Android");
        setContentView(wv);
        wv.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        js("window.goHome && goHome()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Hide our UI whenever we are not the focused app, so a translucent reverse-camera screen can show through.
        if (wv != null) {
            wv.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wv != null) {
            wv.setVisibility(View.VISIBLE);
        }
        js("window.refresh && refresh()");
    }

    @Override
    public void onBackPressed() {
        js("window.goBack && goBack()");
    }

    private void js(String code) {
        if (wv != null) {
            wv.evaluateJavascript(code, null);
        }
    }
}
